select sum(population) as tot_pop
from city
where countrycode='JPN';